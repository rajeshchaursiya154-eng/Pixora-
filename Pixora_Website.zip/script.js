document.getElementById("year").textContent = new Date().getFullYear();

document.querySelector(".menu").addEventListener("click", () => {
  const nav = document.querySelector("nav");
  const open = nav.style.display === "flex";
  nav.style.display = open ? "" : "flex";
  if (!open) {
    nav.style.position = "absolute";
    nav.style.top = "76px";
    nav.style.left = "0";
    nav.style.right = "0";
    nav.style.padding = "20px";
    nav.style.background = "#fff";
    nav.style.flexDirection = "column";
    nav.style.boxShadow = "0 15px 30px #0001";
  }
});

document.getElementById("orderForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const name = document.getElementById("name").value.trim();
  const service = document.getElementById("service").value;
  document.getElementById("formMessage").textContent =
    `Thanks, ${name}! Your ${service} request is ready. Connect this form to WhatsApp/email to receive real orders.`;
  this.reset();
});
