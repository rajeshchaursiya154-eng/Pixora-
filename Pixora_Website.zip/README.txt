# Pixora Website

A responsive one-page business website for Pixora — "We Design, You Shine."

## Files
- index.html — website structure
- style.css — design and responsive layout
- script.js — mobile menu, year, and order form interaction

## How to use
1. Keep all three files in the same folder.
2. Open `index.html` in a browser.
3. Replace the sample poster blocks with your own poster images if desired.
4. To receive real customer orders, connect the form to your preferred email/WhatsApp/form service.

No server is required for the current demo.
